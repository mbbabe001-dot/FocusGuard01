package com.focusguard.app.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AppDatabase(context: Context) : SQLiteOpenHelper(context, "focusguard.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE blocked_apps (
                profile_id INTEGER NOT NULL,
                package_name TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY(profile_id, package_name)
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                strict INTEGER NOT NULL DEFAULT 0,
                screen_limit_minutes INTEGER,
                notification_blocking INTEGER NOT NULL DEFAULT 0
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE app_limits (
                profile_id INTEGER NOT NULL,
                package_name TEXT NOT NULL,
                limit_minutes INTEGER NOT NULL,
                PRIMARY KEY(profile_id, package_name)
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE schedules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                profile_id INTEGER NOT NULL,
                start_minute INTEGER NOT NULL,
                end_minute INTEGER NOT NULL,
                days_mask INTEGER NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE website_rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                host_pattern TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                keyword INTEGER NOT NULL DEFAULT 0
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE notification_rules (
                package_name TEXT PRIMARY KEY,
                enabled INTEGER NOT NULL DEFAULT 1
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE focus_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at INTEGER NOT NULL,
                ended_at INTEGER,
                planned_minutes INTEGER NOT NULL,
                profile_id INTEGER
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE block_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                package_name TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                reason TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("INSERT INTO profiles(name, strict, screen_limit_minutes, notification_blocking) VALUES ('Study', 0, NULL, 1)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
}
