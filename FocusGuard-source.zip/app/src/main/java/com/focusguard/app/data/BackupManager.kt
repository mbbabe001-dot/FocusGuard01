package com.focusguard.app.data

import android.content.Context
import org.json.JSONObject

object BackupManager {
    fun restore(context: Context, json: String) {
        val repo = FocusRepository(context)
        val root = JSONObject(json)
        if (root.has("profiles")) {
            val arr = root.getJSONArray("profiles")
            for (i in 0 until arr.length()) {
                val p = arr.getJSONObject(i)
                val name = p.optString("name", "Imported profile")
                val id = repo.createProfile(name)
                repo.setProfileStrict(id, p.optBoolean("strict", false))
                if (p.has("screenLimitMinutes") && !p.isNull("screenLimitMinutes")) repo.setProfileScreenLimit(id, p.optInt("screenLimitMinutes"))
                repo.setProfileNotificationBlocking(id, p.optBoolean("notificationBlocking", false))
            }
        }
        if (root.has("websiteRules")) {
            val arr = root.getJSONArray("websiteRules")
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                repo.addWebsiteRule(r.optString("pattern", ""), r.optBoolean("keyword", false))
            }
        }
    }
}
