package com.focusguard.app.data

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import java.text.DateFormat
import java.util.Date

class FocusRepository(private val context: Context) {
    private val pm = context.packageManager
    private val usage = context.getSystemService(UsageStatsManager::class.java)
    private val db = AppDatabase(context)

    fun installedApps(): List<InstalledApp> = (if (Build.VERSION.SDK_INT >= 33) {
        pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
    } else {
        @Suppress("DEPRECATION") pm.getInstalledApplications(0)
    }).asSequence()
        .filter { it.packageName != context.packageName }
        .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
        .map { InstalledApp(it.packageName, pm.getApplicationLabel(it).toString(), (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0) }
        .sortedBy { it.label.lowercase() }
        .toList()

    fun usageForRange(begin: Long, end: Long): List<UsageRow> {
        val stats = usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, begin, end).orEmpty()
        val appMap = installedApps().associateBy { it.packageName }
        return stats.mapNotNull { stat ->
            val app = appMap[stat.packageName] ?: return@mapNotNull null
            if (stat.totalTimeInForeground <= 0) return@mapNotNull null
            UsageRow(app, stat.totalTimeInForeground)
        }.sortedByDescending { it.millis }
    }

    fun todaysUsage(): List<UsageRow> {
        val c = java.util.Calendar.getInstance()
        c.set(java.util.Calendar.HOUR_OF_DAY, 0)
        c.set(java.util.Calendar.MINUTE, 0)
        c.set(java.util.Calendar.SECOND, 0)
        c.set(java.util.Calendar.MILLISECOND, 0)
        return usageForRange(c.timeInMillis, System.currentTimeMillis())
    }

    fun timeline(begin: Long, end: Long): List<TimelineItem> {
        val events = usage.queryEvents(begin, end)
        val lastStart = mutableMapOf<String, Long>()
        val result = mutableListOf<TimelineItem>()
        val appMap = installedApps().associateBy { it.packageName }
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            val t = e.timeStamp
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND,
                UsageEvents.Event.ACTIVITY_RESUMED,
                UsageEvents.Event.SCREEN_INTERACTIVE -> lastStart[pkg] = t
                UsageEvents.Event.MOVE_TO_BACKGROUND,
                UsageEvents.Event.ACTIVITY_PAUSED,
                UsageEvents.Event.SCREEN_NON_INTERACTIVE -> {
                    val start = lastStart.remove(pkg) ?: continue
                    if (t > start && appMap.containsKey(pkg)) {
                        val app = appMap.getValue(pkg)
                        result += TimelineItem(pkg, app.label, start, t)
                    }
                }
            }
        }
        return result.sortedByDescending { it.start }
    }

    fun todayMillis(packageName: String): Long = todaysUsage().firstOrNull { it.app.packageName == packageName }?.millis ?: 0L

    fun activeProfileId(): Long = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_PROFILE, 1L)
    fun setActiveProfile(id: Long) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_PROFILE, id).apply()

    fun profiles(): List<Profile> {
        db.readableDatabase.rawQuery("SELECT id,name,strict,screen_limit_minutes,notification_blocking FROM profiles ORDER BY id", null).use { c ->
            val out = mutableListOf<Profile>()
            while (c.moveToNext()) {
                out += Profile(c.getLong(0), c.getString(1), c.getInt(2) != 0, if (c.isNull(3)) null else c.getInt(3), c.getInt(4) != 0)
            }
            return out
        }
    }

    fun setBlocked(profileId: Long, packageName: String, enabled: Boolean) {
        db.writableDatabase.execSQL("INSERT OR REPLACE INTO blocked_apps(profile_id,package_name,enabled) VALUES(?,?,?)", arrayOf<Any?>(profileId, packageName, if (enabled) 1 else 0))
    }

    fun blockedPackages(profileId: Long = activeProfileId()): Set<String> = db.readableDatabase.rawQuery("SELECT package_name FROM blocked_apps WHERE profile_id=? AND enabled=1", arrayOf(profileId.toString())).use { c ->
        buildSet { while (c.moveToNext()) add(c.getString(0)) }
    }

    fun setLimit(profileId: Long, packageName: String, minutes: Int) {
        if (minutes <= 0) db.writableDatabase.execSQL("DELETE FROM app_limits WHERE profile_id=? AND package_name=?", arrayOf<Any?>(profileId, packageName))
        else db.writableDatabase.execSQL("INSERT OR REPLACE INTO app_limits(profile_id,package_name,limit_minutes) VALUES(?,?,?)", arrayOf<Any?>(profileId, packageName, minutes))
    }

    fun limits(profileId: Long = activeProfileId()): Map<String, Int> = db.readableDatabase.rawQuery("SELECT package_name,limit_minutes FROM app_limits WHERE profile_id=?", arrayOf(profileId.toString())).use { c ->
        buildMap { while (c.moveToNext()) put(c.getString(0), c.getInt(1)) }
    }


    fun schedules(profileId: Long = activeProfileId()): List<Schedule> = db.readableDatabase.rawQuery("SELECT id,profile_id,start_minute,end_minute,days_mask,enabled FROM schedules WHERE profile_id=? ORDER BY id", arrayOf(profileId.toString())).use { c ->
        buildList { while (c.moveToNext()) add(Schedule(c.getLong(0), c.getLong(1), c.getInt(2), c.getInt(3), c.getInt(4), c.getInt(5) != 0)) }
    }

    fun addSchedule(profileId: Long, startMinute: Int, endMinute: Int, daysMask: Int) = db.writableDatabase.execSQL("INSERT INTO schedules(profile_id,start_minute,end_minute,days_mask) VALUES(?,?,?,?)", arrayOf<Any?>(profileId, startMinute, endMinute, daysMask))
    fun deleteSchedule(id: Long) = db.writableDatabase.execSQL("DELETE FROM schedules WHERE id=?", arrayOf<Any?>(id))

    fun effectiveProfileId(): Long {
        val now = java.util.Calendar.getInstance()
        val weekday = now.get(java.util.Calendar.DAY_OF_WEEK)
        val bit = 1 shl (weekday - java.util.Calendar.SUNDAY)
        val minute = now.get(java.util.Calendar.HOUR_OF_DAY) * 60 + now.get(java.util.Calendar.MINUTE)
        val all = db.readableDatabase.rawQuery("SELECT id,profile_id,start_minute,end_minute,days_mask,enabled FROM schedules WHERE enabled=1 ORDER BY id", null).use { c ->
            buildList { while (c.moveToNext()) add(Schedule(c.getLong(0), c.getLong(1), c.getInt(2), c.getInt(3), c.getInt(4), c.getInt(5) != 0)) }
        }
        val active = all.firstOrNull { it.enabled && (it.daysMask and bit) != 0 && if (it.startMinute <= it.endMinute) minute in it.startMinute..it.endMinute else (minute >= it.startMinute || minute <= it.endMinute) }
        return active?.profileId ?: activeProfileId()
    }

    fun isProfileStrict(profileId: Long = activeProfileId()): Boolean = profiles().firstOrNull { it.id == profileId }?.strict == true
    fun profileScreenLimit(profileId: Long = activeProfileId()): Int? = profiles().firstOrNull { it.id == profileId }?.screenLimitMinutes
    fun profileNotificationsBlocked(profileId: Long = activeProfileId()): Boolean = profiles().firstOrNull { it.id == profileId }?.notificationBlocking == true

    fun createProfile(name: String): Long {
        db.writableDatabase.execSQL("INSERT INTO profiles(name) VALUES(?)", arrayOf(name))
        return db.readableDatabase.rawQuery("SELECT last_insert_rowid()", null).use { c -> c.moveToFirst(); c.getLong(0) }
    }

    fun setProfileStrict(id: Long, strict: Boolean) = db.writableDatabase.execSQL("UPDATE profiles SET strict=? WHERE id=?", arrayOf<Any?>(if (strict) 1 else 0, id))
    fun setProfileNotificationBlocking(id: Long, enabled: Boolean) = db.writableDatabase.execSQL("UPDATE profiles SET notification_blocking=? WHERE id=?", arrayOf<Any?>(if (enabled) 1 else 0, id))
    fun setProfileScreenLimit(id: Long, minutes: Int?) = db.writableDatabase.execSQL("UPDATE profiles SET screen_limit_minutes=? WHERE id=?", arrayOf<Any?>(minutes, id))

    fun websiteRules(): List<WebsiteRule> = db.readableDatabase.rawQuery("SELECT id,host_pattern,enabled,keyword FROM website_rules ORDER BY id DESC", null).use { c ->
        buildList { while (c.moveToNext()) add(WebsiteRule(c.getLong(0), c.getString(1), c.getInt(2) != 0, c.getInt(3) != 0)) }
    }

    fun addWebsiteRule(pattern: String, keyword: Boolean) = db.writableDatabase.execSQL("INSERT INTO website_rules(host_pattern,keyword) VALUES(?,?)", arrayOf<Any?>(pattern.trim().lowercase(), if (keyword) 1 else 0))
    fun deleteWebsiteRule(id: Long) = db.writableDatabase.execSQL("DELETE FROM website_rules WHERE id=?", arrayOf<Any?>(id))

    fun shouldBlockDomain(host: String): Boolean {
        val h = host.lowercase().trimEnd('.')
        return websiteRules().any { it.enabled && if (it.keyword) h.contains(it.hostPattern) else (h == it.hostPattern || h.endsWith(".${it.hostPattern}")) }
    }

    fun setWebSchedule(startMinute: Int?, endMinute: Int?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply {
            if (startMinute == null || endMinute == null) remove(KEY_WEB_START).remove(KEY_WEB_END)
            else putInt(KEY_WEB_START, startMinute).putInt(KEY_WEB_END, endMinute)
        }.apply()
    }
    fun shortVideoBlockingEnabled(): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SHORT_VIDEO, false)
    fun setShortVideoBlocking(enabled: Boolean) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_SHORT_VIDEO, enabled).apply()
    fun breakActive(): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_BREAK_END, 0L) > System.currentTimeMillis()

    fun webFilterActive(): Boolean {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!p.contains(KEY_WEB_START) || !p.contains(KEY_WEB_END)) return true
        val start = p.getInt(KEY_WEB_START, 0); val end = p.getInt(KEY_WEB_END, 1439)
        val now = java.util.Calendar.getInstance(); val minute=now.get(java.util.Calendar.HOUR_OF_DAY)*60+now.get(java.util.Calendar.MINUTE)
        return if(start <= end) minute in start..end else (minute >= start || minute <= end)
    }

    fun notificationRules(): Set<String> = db.readableDatabase.rawQuery("SELECT package_name FROM notification_rules WHERE enabled=1", null).use { c ->
        buildSet { while (c.moveToNext()) add(c.getString(0)) }
    }
    fun setNotificationRule(packageName: String, enabled: Boolean) = db.writableDatabase.execSQL("INSERT OR REPLACE INTO notification_rules(package_name,enabled) VALUES(?,?)", arrayOf<Any?>(packageName, if (enabled) 1 else 0))

    fun logBlock(packageName: String, reason: String) = db.writableDatabase.execSQL("INSERT INTO block_events(package_name,timestamp,reason) VALUES(?,?,?)", arrayOf<Any?>(packageName, System.currentTimeMillis(), reason))
    fun blockedCountSince(since: Long): Int = db.readableDatabase.rawQuery("SELECT COUNT(*) FROM block_events WHERE timestamp>=?", arrayOf(since.toString())).use { c -> c.moveToFirst(); c.getInt(0) }
    fun startFocus(plannedMinutes: Int, profileId: Long?) : Long {
        val now = System.currentTimeMillis()
        db.writableDatabase.execSQL("INSERT INTO focus_sessions(started_at,planned_minutes,profile_id) VALUES(?,?,?)", arrayOf<Any?>(now, plannedMinutes, profileId))
        return db.readableDatabase.rawQuery("SELECT last_insert_rowid()", null).use { c -> c.moveToFirst(); c.getLong(0) }
    }
    fun endFocus(id: Long) = db.writableDatabase.execSQL("UPDATE focus_sessions SET ended_at=? WHERE id=?", arrayOf<Any?>(System.currentTimeMillis(), id))
    fun focusHistory(): List<String> = db.readableDatabase.rawQuery("SELECT started_at,planned_minutes,ended_at FROM focus_sessions ORDER BY started_at DESC LIMIT 20", null).use { c ->
        buildList {
            while (c.moveToNext()) {
                val start = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(c.getLong(0)))
                val planned = c.getInt(1)
                val end = if (c.isNull(2)) "active" else "done"
                add("$start • ${planned}m • $end")
            }
        }
    }

    fun lockModeEnabled(): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_LOCK_MODE, false)
    fun setLockMode(enabled: Boolean) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_LOCK_MODE, enabled).apply()
    fun setLockPin(pin: String) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_PIN_HASH, sha256(pin)).apply()
    fun hasLockPin(): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(KEY_PIN_HASH)
    fun checkLockPin(pin: String): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PIN_HASH, "") == sha256(pin)
    private fun sha256(value: String): String = java.security.MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }

    fun exportJson(): String {
        val sb = StringBuilder()
        sb.append("{\n\"profiles\":[")
        profiles().forEachIndexed { i, p ->
            if (i > 0) sb.append(',')
            sb.append("{\"id\":${p.id},\"name\":\"${escape(p.name)}\",\"strict\":${p.strict},\"screenLimitMinutes\":${p.screenLimitMinutes ?: "null"},\"notificationBlocking\":${p.notificationBlocking}}")
        }
        sb.append("],\n\"websiteRules\":[")
        websiteRules().forEachIndexed { i, r -> if (i > 0) sb.append(','); sb.append("{\"pattern\":\"${escape(r.hostPattern)}\",\"keyword\":${r.keyword}}") }
        sb.append("]\n}")
        return sb.toString()
    }
    private fun escape(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")

    companion object {
        const val PREFS = "focusguard"
        const val KEY_PROFILE = "active_profile"
        const val KEY_DARK = "dark_mode"
        const val KEY_STRICT_LOCK = "strict_lock"
        const val KEY_UNLOCK_UNTIL_PREFIX = "unlock_until_"
        const val KEY_FOCUS_ACTIVE = "focus_active"
        const val KEY_FOCUS_END = "focus_end"
        const val KEY_LOCK_MODE = "lock_mode"
        const val KEY_PIN_HASH = "pin_hash"
        const val KEY_WEB_START = "web_start"
        const val KEY_WEB_END = "web_end"
        const val KEY_SHORT_VIDEO = "short_video_block"
        const val KEY_BREAK_END = "break_end"
    }
}
