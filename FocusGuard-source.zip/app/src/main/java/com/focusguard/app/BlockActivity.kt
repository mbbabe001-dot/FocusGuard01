package com.focusguard.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.focusguard.app.data.FocusRepository
import com.focusguard.app.ui.AppTheme

class BlockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(EXTRA_PACKAGE).orEmpty()
        val label = intent.getStringExtra(EXTRA_LABEL).orEmpty().ifBlank { pkg }
        setContent {
            val repo = remember { FocusRepository(applicationContext) }
            val strict = repo.isProfileStrict()
            val prefs = applicationContext.getSharedPreferences(FocusRepository.PREFS, 0)
            var remaining by remember { mutableLongStateOf((prefs.getLong(FocusRepository.KEY_UNLOCK_UNTIL_PREFIX + pkg, 0L) - System.currentTimeMillis()).coerceAtLeast(0L)) }
            LaunchedEffect(Unit) {
                while (remaining > 0) {
                    remaining = (prefs.getLong(FocusRepository.KEY_UNLOCK_UNTIL_PREFIX + pkg, 0L) - System.currentTimeMillis()).coerceAtLeast(0L)
                    kotlinx.coroutines.delay(1000)
                }
            }
            AppTheme(darkTheme = prefs.getBoolean(FocusRepository.KEY_DARK, false)) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Stay focused", style = MaterialTheme.typography.headlineLarge)
                        Text("$label is blocked by your active FocusGuard profile.", style = MaterialTheme.typography.bodyLarge)
                        Text("Choose a real reason to stay focused. You can leave this screen with Home.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (!strict) {
                            Button({
                                prefs.edit().putLong(FocusRepository.KEY_UNLOCK_UNTIL_PREFIX + pkg, System.currentTimeMillis()+5*60_000L).apply()
                                repo.logBlock(pkg, "temporary-unlock")
                                finish()
                            }) { Text("Unlock for 5 minutes") }
                        } else {
                            Text("Strict mode is active. Temporary unlock is disabled.", color = MaterialTheme.colorScheme.error)
                        }
                        OutlinedButton({ finish() }) { Text("Go back") }
                    }
                }
            }
        }
    }
    companion object {
        const val EXTRA_PACKAGE = "package"
        const val EXTRA_LABEL = "label"
    }
}
