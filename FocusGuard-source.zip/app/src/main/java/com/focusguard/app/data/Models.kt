package com.focusguard.app.data

data class InstalledApp(
    val packageName: String,
    val label: String,
    val isSystem: Boolean
)

data class UsageRow(
    val app: InstalledApp,
    val millis: Long,
    val launches: Int = 0
)

data class TimelineItem(
    val packageName: String,
    val label: String,
    val start: Long,
    val end: Long
)

data class BlockRule(
    val packageName: String,
    val enabled: Boolean,
    val temporaryUnlockUntil: Long = 0L
)

data class Profile(
    val id: Long,
    val name: String,
    val strict: Boolean,
    val screenLimitMinutes: Int?,
    val notificationBlocking: Boolean
)

data class WebsiteRule(
    val id: Long,
    val hostPattern: String,
    val enabled: Boolean,
    val keyword: Boolean
)

data class Schedule(
    val id: Long,
    val profileId: Long,
    val startMinute: Int,
    val endMinute: Int,
    val daysMask: Int,
    val enabled: Boolean
)

data class AppLimit(
    val packageName: String,
    val limitMinutes: Int,
    val profileId: Long = 0L
)
