package com.focusguard.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

class FocusAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val nm=context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "FocusGuard focus", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(FOCUS_ID, NotificationCompat.Builder(context, CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_lock).setContentTitle("Focus session finished").setContentText("Time for a short reset before your next session.").setAutoCancel(true).build())
        context.getSharedPreferences(com.focusguard.app.data.FocusRepository.PREFS,0).edit().putBoolean(com.focusguard.app.data.FocusRepository.KEY_FOCUS_ACTIVE,false).putLong(com.focusguard.app.data.FocusRepository.KEY_FOCUS_END,0L).apply()
    }
    companion object { const val CHANNEL="focusguard_focus"; const val FOCUS_ID=702 }
}
