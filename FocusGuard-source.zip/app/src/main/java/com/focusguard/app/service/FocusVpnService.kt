package com.focusguard.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.focusguard.app.MainActivity
import com.focusguard.app.data.FocusRepository
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Local DNS-filter VPN. It intentionally only handles IPv4 UDP DNS packets and does not
 * inspect HTTPS payloads. Apps using DNS-over-HTTPS/HTTPS records can require additional
 * controls and are documented as a bypass class in the UI/README.
 */
class FocusVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private lateinit var repo: FocusRepository
    private var worker: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        repo = FocusRepository(applicationContext)
        when (intent?.action) {
            ACTION_STOP -> stopFilter()
            ACTION_START, null -> startFilter()
        }
        return START_STICKY
    }

    private fun startFilter() {
        if (running.get()) return
        startForeground(NOTIFICATION_ID, notification())
        vpnInterface = Builder()
            .setSession("FocusGuard Web Filter")
            .setMtu(1500)
            .addAddress("10.11.0.2", 32)
            .addRoute("10.11.0.1", 32)
            .addDnsServer("10.11.0.1")
            .establish()
        if (vpnInterface == null) return
        running.set(true)
        worker = Thread { loop() }.also { it.start() }
    }

    private fun stopFilter() {
        running.set(false)
        worker?.interrupt()
        worker = null
        vpnInterface?.close()
        vpnInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun loop() {
        val pfd = vpnInterface ?: return
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        while (running.get()) {
            try {
                val len = input.read(buf)
                if (len <= 0) continue
                val packet = buf.copyOf(len)
                val dns = parseDnsUdp(packet) ?: continue
                if (dns.destPort != 53) continue
                val replyPayload = if (repo.webFilterActive() && repo.shouldBlockDomain(dns.host)) buildBlockedDnsResponse(dns.payload) else forwardDns(dns.payload)
                val response = buildUdpIpv4Packet(
                    srcIp = dns.destIp,
                    dstIp = dns.srcIp,
                    srcPort = 53,
                    dstPort = dns.srcPort,
                    payload = replyPayload
                )
                output.write(response)
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
        input.close(); output.close()
    }

    private data class DnsPacket(val srcIp:Int, val destIp:Int, val srcPort:Int, val destPort:Int, val payload:ByteArray, val host:String)

    private fun parseDnsUdp(packet: ByteArray): DnsPacket? {
        if (packet.size < 28) return null
        val version = (packet[0].toInt() ushr 4) and 0xF
        val ihl = (packet[0].toInt() and 0xF) * 4
        if (version != 4 || packet[9].toInt() and 0xFF != 17 || ihl < 20 || packet.size < ihl + 8) return null
        val src = intAt(packet,12); val dst=intAt(packet,16)
        val srcPort=((packet[ihl].toInt() and 0xFF) shl 8) or (packet[ihl+1].toInt() and 0xFF)
        val dstPort=((packet[ihl+2].toInt() and 0xFF) shl 8) or (packet[ihl+3].toInt() and 0xFF)
        val payload = packet.copyOfRange(ihl+8, packet.size)
        if (dstPort != 53 || payload.size < 12) return null
        val host = parseDnsName(payload, 12) ?: return null
        return DnsPacket(src,dst,srcPort,dstPort,payload,host)
    }

    private fun parseDnsName(payload: ByteArray, start: Int): String? {
        var i=start; val parts=mutableListOf<String>(); var guard=0
        while (i < payload.size && guard++ < 64) {
            val len=payload[i].toInt() and 0xFF
            if (len==0) return parts.joinToString(".")
            if ((len and 0xC0)==0xC0) return parts.joinToString(".")
            if (i+1+len>payload.size) return null
            parts += payload.copyOfRange(i+1,i+1+len).toString(Charsets.US_ASCII)
            i += 1+len
        }
        return null
    }

    private fun forwardDns(payload: ByteArray): ByteArray {
        DatagramSocket().use { socket ->
            protect(socket)
            socket.soTimeout = 2500
            val target = InetSocketAddress("1.1.1.1",53)
            socket.send(DatagramPacket(payload,payload.size,target))
            val reply=ByteArray(4096); val p=DatagramPacket(reply,reply.size); socket.receive(p)
            return p.data.copyOf(p.length)
        }
    }

    private fun buildBlockedDnsResponse(query: ByteArray): ByteArray {
        if (query.size < 12) return query
        val response=query.copyOf()
        response[2]=(response[2].toInt() or 0x80).toByte() // response flag
        response[3]=(response[3].toInt() or 0x03).toByte() // NXDOMAIN
        response[6]=0; response[7]=0; response[8]=0; response[9]=0; response[10]=0; response[11]=0
        return response
    }

    private fun buildUdpIpv4Packet(srcIp:Int,dstIp:Int,srcPort:Int,dstPort:Int,payload:ByteArray):ByteArray {
        val total=20+8+payload.size; val b=ByteBuffer.allocate(total)
        b.put(0x45.toByte()); b.put(0); b.putShort(total.toShort()); b.putShort(0); b.putShort(0x4000.toShort()); b.put(64.toByte()); b.put(17.toByte()); b.putShort(0); b.putInt(srcIp); b.putInt(dstIp)
        val udpStart=b.position(); b.putShort(srcPort.toShort()); b.putShort(dstPort.toShort()); b.putShort((8+payload.size).toShort()); b.putShort(0); b.put(payload)
        val arr=b.array(); putChecksum(arr,10,checksum(arr,0,20))
        putChecksum(arr,udpStart+6,udpChecksum(arr,udpStart,payload.size,srcIp,dstIp))
        return arr
    }

    private fun checksum(a:ByteArray,start:Int,len:Int):Short { var sum=0L; var i=start; while(i<start+len){sum += ((a[i].toInt() and 0xFF) shl 8) + if(i+1<start+len) a[i+1].toInt() and 0xFF else 0; i+=2; if(sum>0xFFFF) sum=(sum and 0xFFFF)+(sum ushr 16)}; sum=(sum and 0xFFFF)+(sum ushr 16); return sum.inv().toShort() }
    private fun udpChecksum(a:ByteArray,start:Int,payloadLen:Int,src:Int,dst:Int):Short { var sum=0L; fun add(x:Int){sum+=x; if(sum>0xFFFF) sum=(sum and 0xFFFF)+(sum ushr 16)}; add((src ushr 16) and 0xFFFF); add(src and 0xFFFF); add((dst ushr 16) and 0xFFFF); add(dst and 0xFFFF); add(17); add(8+payloadLen); var i=start; val end=a.size; while(i<end){val hi=(a[i].toInt() and 0xFF) shl 8; val lo=if(i+1<end) a[i+1].toInt() and 0xFF else 0; add(hi or lo); i+=2}; return sum.inv().toShort() }
    private fun putChecksum(a:ByteArray,offset:Int,value:Short){a[offset]=(value.toInt() ushr 8).toByte(); a[offset+1]=value.toByte()}
    private fun intAt(a:ByteArray,o:Int)=((a[o].toInt() and 0xFF) shl 24) or ((a[o+1].toInt() and 0xFF) shl 16) or ((a[o+2].toInt() and 0xFF) shl 8) or (a[o+3].toInt() and 0xFF)

    private fun notification(): android.app.Notification {
        val nm=getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel(CHANNEL,"Web filter",NotificationManager.IMPORTANCE_LOW))
        val pi=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle("FocusGuard web filter active").setContentText("Domain blocking is running on this device").setContentIntent(pi).setOngoing(true).build()
    }

    override fun onDestroy(){stopFilter();super.onDestroy()}
    companion object { const val ACTION_START="focusguard.START_VPN"; const val ACTION_STOP="focusguard.STOP_VPN"; const val CHANNEL="focusguard_vpn"; const val NOTIFICATION_ID=701 }
}
