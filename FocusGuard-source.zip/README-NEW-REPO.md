# FocusGuard — New Repository Starter

This package is prepared for a phone-only GitHub Actions build.

Build stack:
- Android Gradle Plugin 8.13.2
- Kotlin 2.3.21
- Gradle 8.13 (provided by GitHub Actions)
- JDK 17
- compileSdk 36

The repository should contain the extracted project files at its root. Do not put the project inside an extra `FocusGuard/` directory.

For the exact GitHub setup, follow the instructions in the chat where this package was provided.
