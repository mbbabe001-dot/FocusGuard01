# Complete FocusGuard build order

The implementation follows the requested sequence: **What → Why → What you need → Android permission/API → UI → database → code structure → implementation → testing → next feature**.

## Phase 0 — Basic foundation

### 1. Android Studio project
What: Gradle Android app, Kotlin, Compose, API 36/36.1-compatible tooling.
Why: stable foundation and modern Android UI.
Need: Android Studio, JDK 17, SDK 36.1.
API: Android Gradle Plugin 8.13.x, Kotlin 2.3.x, Compose BOM 2026.09.00.
UI: none yet.
DB: none.
Code: `settings.gradle.kts`, root/app Gradle files.
Implementation: open the folder and sync.
Testing: Gradle sync + empty app launch.

### 2. App design/theme
What: Material 3 light/dark theme.
Why: consistent UI and adaptive components.
Need: Compose Material 3.
API: Compose runtime/UI.
UI: `AppTheme`.
DB: `dark_mode` preference.
Code: `ui/Theme.kt`, `MainActivity.kt`.
Testing: toggle dark mode, rotate device.

### 3. Navigation and screens
What: dashboard, apps, timeline, focus, stats, settings, profiles, web control.
Why: separates configuration from enforcement and reporting.
Need: Compose state navigation.
API: Activity + Compose.
UI: bottom navigation + screen enum.
DB: none.
Code: `MainActivity.kt`.
Testing: navigate all tabs repeatedly, rotate, background/restore.

### 4. Local database/settings
What: SQLite tables + SharedPreferences.
Why: rules survive app restarts without a server.
Need: SQLiteOpenHelper.
API: `SQLiteOpenHelper`, SharedPreferences.
UI: future settings/profile editors.
DB: blocked_apps, profiles, app_limits, schedules, website_rules, notification_rules, focus_sessions, block_events.
Code: `data/AppDatabase.kt`, `data/FocusRepository.kt`.
Testing: insert/update/delete data; force-stop; reopen.

### 5. Required Android permissions
What: usage access, AccessibilityService, notification listener, VPN, notifications and battery optimization guidance.
Why: each subsystem is protected by Android user consent/settings.
Need: manifest + in-app guidance.
API: UsageStatsManager, AccessibilityService, NotificationListenerService, VpnService.
UI: dashboard permission cards.
DB: permission status is not persisted; query live system state.
Code: `util/Permissions.kt`.
Testing: every grant/deny/revoke path.

## Phase 1 — Core tracking

### 6. Detect installed apps
What: launcher-visible installed apps.
Why: user needs an app list to block/manage.
Need: PackageManager; broad visibility is a Play-policy-sensitive permission.
API: `PackageManager`.
UI: Apps screen.
DB: package names only when selected.
Code: `FocusRepository.installedApps()`.
Testing: install/uninstall apps; system vs user apps.

### 7. Read app usage time
What: aggregate foreground time.
Why: daily limits and reports depend on it.
Need: Usage Access.
API: `UsageStatsManager.queryUsageStats()`.
UI: usage cards.
DB: not required for raw live stats.
Code: `FocusRepository.usageForRange()`.
Testing: compare with Android Digital Wellbeing for several apps.

### 8. Show today's screen-time
What: sum today's app usage.
Why: primary dashboard metric.
Need: daily boundary + usage access.
UI: dashboard card.
DB: none.
Code: `todaysUsage()`.
Testing: midnight transition and timezone change.

### 9. Show individual app usage
What: per-app duration.
Why: identify high-use apps and enforce limits.
UI: Apps/dashboard.
DB: optional rules only.
Code: `UsageRow`.
Testing: foreground several apps and compare totals.

### 10. Usage history/timeline
What: recent UsageEvents converted to foreground intervals.
Why: visual timeline and debugging.
API: `UsageStatsManager.queryEvents()`.
UI: Timeline screen.
DB: live system events; can later be snapshotted locally.
Code: `FocusRepository.timeline()`.
Testing: lock/unlock, app switches, split screen and launcher transitions.

## Phase 2 — Main App Blocker

### 11. Select apps to block
What: per-profile switches.
Why: define the user's blocking rule.
DB: `blocked_apps`.
UI: Apps screen.
Code: `setBlocked()`.
Testing: select/unselect, restart service.

### 12. Detect when a blocked app opens
What: Accessibility window/package events.
Why: UsageStats is too coarse for immediate enforcement.
API: AccessibilityService.
UI: onboarding disclosure + system settings.
Code: `AppBlockAccessibilityService`.
Testing: fast app switching; OEM background restrictions.

### 13. Show custom blocking screen
What: FocusGuard activity displayed when a rule is hit.
Why: user-friendly enforcement instead of silent failure.
UI: `BlockActivity`.
DB: block event.
Code: `BlockActivity.kt`.
Testing: launch blocked app from launcher, notification, recents.

### 14. Allow/deny access
What: strict profile blocks temporary unlock; normal profile permits unlock.
Why: support flexible vs committed sessions.
DB: per-package temporary unlock timestamp in preferences.
Code: `BlockActivity` + service.
Testing: unlock expires, reboot, strict mode.

### 15. Temporary unlock option
What: five-minute temporary unlock.
Why: emergency access without changing permanent rules.
DB/settings: `unlock_until_<package>`.
Testing: timer expiry and app relaunch.

## Phase 3 — Limits & Scheduling

### 16. Daily app limits
What: minutes per selected app.
Why: user can allow an app but cap it.
DB: `app_limits`.
UI: App “Limit” control.
Code: service compares usage against limit.
Testing: set one-minute limit and verify block.

### 17. Start/end-time schedules
What: current profile may become active only during a time window.
Why: study/work hours.
DB: `schedules`.
Code: `effectiveProfileId()`.
Testing: just before and after start/end.

### 18. Recurring schedules
Current implementation: daily recurring schedule with a day-mask data model.
Next implementation step: expose seven weekday chips in Profiles UI for custom weekly masks.
Testing: each weekday boundary.

### 19. Multiple blocking profiles
What: named profiles with independent rules.
Why: Study/Work/Sleep/Free-time scenarios.
DB: `profiles` + profile-scoped rules.
UI: Profiles.
Testing: switch profiles; confirm selected rules change.

### 20. Screen-time limit
What: total device daily limit for the active profile.
Why: cap all device usage, not only named apps.
DB: `profiles.screen_limit_minutes`.
Code: accessibility service total-usage check.
Testing: low limit and multiple apps.

## Phase 4 — Strong blocking

### 21. Strict Mode
What: disables five-minute unlock.
Why: stronger commitment during a session.
DB: `profiles.strict`.
UI: profile switch.
Testing: unlock button absent.

### 22. Lock Mode
What: protects FocusGuard settings with a user PIN.
Why: prevents accidental self-disable inside the app.
DB/settings: SHA-256 PIN hash + lock flag.
UI: Settings/Profile PIN dialog.
Testing: correct/incorrect PIN, enable/disable.

### 23. Prevent easy changes during active session
What: Lock Mode gates FocusGuard's profile-setting changes.
Why: avoid accidental rule edits.
Limit: cannot make Android system settings or accessibility settings impossible to change from a normal personal app.
Testing: try every guarded profile action while locked.

### 24. Break/Take-a-break
What: five-minute break suppresses normal focus blocking unless a hard limit is already exceeded.
Why: practical recovery without destroying the session.
Settings: `break_end`.
UI: Focus screen button.
Testing: break starts, expires, and enforcement resumes.

## Phase 5 — Productivity

### 25. Focus/Pomodoro timer
What: 15/25/45/60-minute timer.
Why: direct study/work workflow.
DB: `focus_sessions`.
UI: Focus screen.
Testing: timer background/restore.

### 26. Automatic blocking during focus
What: active profile's blocked apps are enforced during focus.
Why: timer should actually change device behavior.
Code: shared `KEY_FOCUS_ACTIVE`/`KEY_FOCUS_END` state + AccessibilityService.
Testing: start focus, open blocked app.

### 27. Study/work profiles
What: named profiles + schedules.
Why: same blocker engine, different contexts.
UI/DB: Profiles.
Testing: profile switch + schedule.

### 28. Focus session history
What: session start/planned/done state.
Why: measure consistency.
DB: `focus_sessions`.
Current UI: timer foundation; history query exists in repository.
Next step: add history card to Focus screen.

## Phase 6 — Website control

### 29. Website detection
What: inspect DNS queries inside local VpnService.
Why: browser-independent domain-level blocking for DNS-based traffic.
API: `VpnService`.
UI: Web Control.
Code: `FocusVpnService`.
Testing: Chrome/Firefox and a second browser.

### 30. Website blocking
What: exact domain/subdomain blocking with NXDOMAIN.
Why: block sites without decrypting HTTPS.
DB: `website_rules`.
Testing: blocked domain, unblocked domain, subdomain.

### 31. Website schedules
What: daily on/off window for the local DNS filter.
Why: block distracting websites during study hours.
Settings: web start/end minutes.
Code: `webFilterActive()`.
Testing: start/end boundaries.

### 32. Keyword/site filtering
What: domain keyword entries (for example “shorts”).
Why: broad rule matching.
DB: `website_rules.keyword`.
Testing: positive and false-positive cases.

## Phase 7 — Notifications & extra controls

### 33. Notification blocking
What: dismiss notifications from selected blocked apps/profile apps.
Why: prevent notification-driven distraction.
API: NotificationListenerService.
DB: `notification_rules` + profile notification mode.
Code: `FocusNotificationListenerService`.
Testing: normal/ongoing/media notifications and listener revocation.

### 34. Shorts/Reels blocking
What: Accessibility-based detection for known social-video packages when event text/content description contains `shorts`, `reels`, or `short video`.
Why: stop a specific high-distraction surface without inspecting HTTPS content.
Limit: UI/localization can change.
Testing: YouTube Shorts, Instagram Reels and false-positive titles.

### 35. Distraction warnings
Current implementation: custom blocking screen is the warning/interruption surface.
Next step: add configurable “soft warning before hard block” state.

### 36. Strict alarm
Current implementation: focus completion alarm uses an inexact `AlarmManager` reminder and a notification.
Why: user gets a visible session-end cue.
Next step: optional exact-alarm path only if the use case and permission policy justify it.

## Phase 8 — Statistics

### 37. Daily report
What: today's usage list + block count.
UI: Stats.

### 38. Weekly/monthly report
Next step: aggregate seven/30 day snapshots into local report tables. Current code has daily live usage primitives.

### 39. Charts
What: Compose Canvas bar chart.
UI: Stats.
Testing: empty/one/many apps and large values.

### 40. Most-used apps
What: sorted usage list.
Code: `usageForRange()`.

### 41. Time saved/streaks
Current implementation intentionally avoids inventing “saved minutes”. Block attempts are tracked; focus session data exists. A production next step should define a measurable saved-time model and consecutive-day streak algorithm before exposing a “saved” number.

## Phase 9 — Polish

### 42. Dark mode
Implemented via SharedPreferences + Compose theme.

### 43. Backup/restore
Implemented as local JSON export/import for profiles and website rules. Extend the JSON schema to include blocked apps, limits, schedules and notification rules before calling this production-complete.

### 44. Battery optimization handling
Implemented guidance and Settings shortcut. Real-world OEM testing remains essential.

### 45. Accessibility/permission guidance
Implemented dashboard permission cards. Production build must also include prominent disclosures immediately before sensitive API consent flows.

### 46. Error handling
Current services fail softly where possible. Production next step: surface a persistent “service unavailable” state and self-test diagnostics.

### 47. Privacy/security
Implemented local-first storage and no analytics/backend. Production: add a formal privacy policy, threat model, encrypted secrets where appropriate, and release Data Safety declaration.

### 48. Performance optimization
Current approach caches only short-lived Compose state and queries installed apps on demand. Production next step: memoized app inventory, background snapshots and batched DB reads.

### 49. Testing
Required test layers:
- unit: minute parsing, schedule windows, domain matching, DB CRUD;
- instrumentation: permission flows, block activity launch, receiver behavior;
- device matrix: Pixel + at least two OEMs;
- battery: screen-off, reboot, process death, app standby;
- network: IPv4 DNS, IPv6, DoH/DoT, VPN conflicts;
- Play pre-check: permissions, disclosures, policy declarations.

### 50. Play Store release
Before production release:
1. Build AAB with release signing.
2. Run Android lint and instrumentation tests.
3. Complete declarations for AccessibilityService, app visibility, VpnService and other sensitive APIs as applicable.
4. Publish privacy policy/Data Safety information.
5. Demonstrate the core use of sensitive APIs during review.
6. Test on clean devices and upgrade paths.
