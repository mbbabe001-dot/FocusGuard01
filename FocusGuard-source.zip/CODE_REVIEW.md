# FocusGuard pre-build code review

Reviewed the Kotlin/Compose source for the errors exposed by the GitHub Actions build.

## Compile blockers fixed

1. Kotlin named-argument ordering in `MainActivity.kt`:
   - `Text("Apps", style = ..., Modifier.weight(...))`
   - `Text(profileName, style = ..., Modifier.weight(...))`
   - `Text("Web control", style = ..., Modifier.weight(...))`
   These were changed to use `modifier = ...` before/with the named arguments.

2. Compose compiler error in the statistics chart:
   - `MaterialTheme.colorScheme.primary` was evaluated inside the `Canvas` draw lambda.
   - `MaterialTheme` is a composable API and cannot be called from the non-composable `DrawScope` lambda.
   - The color is now read before `Canvas` and passed into `drawRoundRect`.

## Earlier fixes retained

- Android Gradle Plugin 8.13.2
- Kotlin 2.3.21
- Gradle 8.13
- JDK 17
- Kotlin compiler `JvmTarget.JVM_17`
- Compose BOM declared through `implementation(platform(...))`
- SQLite `execSQL` argument arrays made explicitly typed where mixed numeric/string/null values are used.

## Review scope

All Kotlin files under `app/src/main/java` were inspected for the same Compose named-argument pattern and `MaterialTheme` use in non-composable lambdas. No additional instances of those specific compiler blockers were found.

A real Android Gradle build remains the final verification step because the container used for source review does not contain the Android SDK/Jetpack dependency classpath.
